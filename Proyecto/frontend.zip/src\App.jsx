import {
  Navigate,
  Route,
  Routes,
} from "react-router-dom"

import Layout from "./components/Layout"

import AccessControl from "./pages/AccessControl"
import AccessHistory from "./pages/AccessHistory"
import Dashboard from "./pages/Dashboard"
import FaceEnrollment from "./pages/FaceEnrollment"
import Permissions from "./pages/Permissions"
import Users from "./pages/Users"
import Vehicles from "./pages/Vehicles"


function App() {

  return (
    <Routes>

      <Route element={<Layout />}>

        <Route
          path="/"
          element={<Dashboard />}
        />

        <Route
          path="/users"
          element={<Users />}
        />

        <Route
          path="/users/:userId/face"
          element={<FaceEnrollment />}
        />

        <Route
          path="/vehicles"
          element={<Vehicles />}
        />

        <Route
          path="/permissions"
          element={<Permissions />}
        />

        <Route
          path="/history"
          element={<AccessHistory />}
        />

        <Route
          path="/access-control"
          element={<AccessControl />}
        />

      </Route>


      <Route
        path="*"
        element={
          <Navigate
            to="/"
            replace
          />
        }
      />

    </Routes>
  )
}


export default App