import {
  CarFront,
  History,
  LayoutDashboard,
  ScanFace,
  ShieldCheck,
  Users,
} from "lucide-react"

import {
  NavLink,
} from "react-router-dom"


const menu = [
  {
    to: "/",
    label: "Dashboard",
    icon: LayoutDashboard,
  },
  {
    to: "/users",
    label: "Usuarios",
    icon: Users,
  },
  {
    to: "/vehicles",
    label: "Vehículos",
    icon: CarFront,
  },
  {
    to: "/permissions",
    label: "Permisos",
    icon: ShieldCheck,
  },
  {
    to: "/history",
    label: "Historial",
    icon: History,
  },
  {
    to: "/access-control",
    label: "Control de acceso",
    icon: ScanFace,
  },
]


function Sidebar() {
  return (
    <aside className="sidebar">

      <div className="sidebar-brand">
        <div className="brand-icon">
          SP
        </div>

        <div>
          <strong>
            SmartPark
          </strong>

          <span>
            Universidad Central
          </span>
        </div>
      </div>


      <nav className="sidebar-nav">

        {menu.map(
          ({
            to,
            label,
            icon: Icon,
          }) => (

            <NavLink
              key={to}
              to={to}
              end={to === "/"}
              className={
                ({ isActive }) =>
                  isActive
                    ? "nav-item active"
                    : "nav-item"
              }
            >

              <Icon size={20} />

              <span>
                {label}
              </span>

            </NavLink>

          )
        )}

      </nav>


      <div className="sidebar-footer">

        <div className="system-dot" />

        <div>
          <strong>
            SmartPark UCE
          </strong>

          <span>
            Sistema de acceso vehicular
          </span>
        </div>

      </div>

    </aside>
  )
}


export default Sidebar