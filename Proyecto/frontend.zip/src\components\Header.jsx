import {
  Bell,
  CircleUserRound,
} from "lucide-react"


function Header() {
  return (
    <header className="topbar">

      <div>
        <p className="topbar-eyebrow">
          Sistema inteligente de acceso
        </p>

        <h1>
          SmartPark UCE
        </h1>
      </div>


      <div className="topbar-actions">

        <button
          className="icon-button"
          type="button"
          aria-label="Notificaciones"
        >
          <Bell size={20} />
        </button>


        <div className="admin-profile">

          <CircleUserRound size={30} />

          <div>
            <strong>
              Administrador
            </strong>

            <span>
              SmartPark
            </span>
          </div>

        </div>

      </div>

    </header>
  )
}


export default Header