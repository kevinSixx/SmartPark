const API_URL =
  import.meta.env.VITE_API_URL


async function request(
  path,
  options = {}
) {

  const response = await fetch(
    `${API_URL}${path}`,
    options
  )


  if (!response.ok) {

    let detail =
      "Error al comunicarse con SmartPark"


    try {

      const body =
        await response.json()

      detail =
        body.detail
        ||
        detail

    } catch {
      // Respuesta sin JSON.
    }


    throw new Error(
      typeof detail === "string"
        ? detail
        : JSON.stringify(detail)
    )
  }


  return response.json()
}


/* ============================================================
   SISTEMA
   ============================================================ */

export function getBackendHealth() {

  return request(
    "/health"
  )
}


/* ============================================================
   USUARIOS
   ============================================================ */

export function getUsers() {

  return request(
    "/api/v1/users"
  )
}


export function getUser(
  userId
) {

  return request(
    `/api/v1/users/${userId}`
  )
}


export function createUser(
  data
) {

  return request(
    "/api/v1/users",
    {
      method:
        "POST",

      headers: {
        "Content-Type":
          "application/json",
      },

      body:
        JSON.stringify(data),
    }
  )
}


/* ============================================================
   VEHÍCULOS
   ============================================================ */

export function getVehicles() {

  return request(
    "/api/v1/vehicles"
  )
}


export function createVehicle(
  data
) {

  return request(
    "/api/v1/vehicles",
    {
      method:
        "POST",

      headers: {
        "Content-Type":
          "application/json",
      },

      body:
        JSON.stringify(data),
    }
  )
}


/* ============================================================
   PERMISOS
   ============================================================ */

export function getPermissions() {

  return request(
    "/api/v1/permissions"
  )
}


export function createPermission(
  data
) {

  return request(
    "/api/v1/permissions",
    {
      method:
        "POST",

      headers: {
        "Content-Type":
          "application/json",
      },

      body:
        JSON.stringify(data),
    }
  )
}


/* ============================================================
   HISTORIAL
   ============================================================ */

export function getAccessEvents() {

  return request(
    "/api/v1/access-events"
  )
}


/* ============================================================
   CONTROL DE ACCESO
   ============================================================ */

export async function processAccess(
  faceImage,
  plateImage,
  eventType
) {

  const formData =
    new FormData()


  formData.append(
    "face_image",
    faceImage
  )


  formData.append(
    "plate_image",
    plateImage
  )


  formData.append(
    "event_type",
    eventType
  )


  const response = await fetch(
    `${API_URL}/api/v1/access/process`,
    {
      method:
        "POST",

      body:
        formData,
    }
  )


  if (!response.ok) {

    let detail =
      "No se pudo procesar el acceso"


    try {

      const body =
        await response.json()

      detail =
        body.detail
        ||
        detail

    } catch {
      // Respuesta sin JSON.
    }


    throw new Error(
      typeof detail === "string"
        ? detail
        : JSON.stringify(detail)
    )
  }


  return response.json()
}


/* ============================================================
   BIOMETRÍA FACIAL
   ============================================================ */

export async function getFaceProfile(
  userId
) {

  const response = await fetch(
    `${API_URL}/api/v1/face-profiles/${userId}`
  )


  if (
    response.status === 404
  ) {

    return null
  }


  if (!response.ok) {

    let detail =
      "No se pudo consultar el perfil facial"


    try {

      const body =
        await response.json()

      detail =
        body.detail
        ||
        detail

    } catch {
      // Sin JSON.
    }


    throw new Error(
      typeof detail === "string"
        ? detail
        : JSON.stringify(detail)
    )
  }


  return response.json()
}


export async function enrollFace(
  userId,
  images
) {

  const formData =
    new FormData()


  formData.append(
    "user_id",
    String(userId)
  )


  images.forEach(
    (image) => {

      formData.append(
        "images",
        image
      )

    }
  )


  const response = await fetch(
    `${API_URL}/api/v1/face-profiles/enroll`,
    {
      method:
        "POST",

      body:
        formData,
    }
  )


  if (!response.ok) {

    let detail =
      "No se pudo registrar el rostro"


    try {

      const body =
        await response.json()

      detail =
        body.detail
        ||
        detail

    } catch {
      // Sin JSON.
    }


    throw new Error(
      typeof detail === "string"
        ? detail
        : JSON.stringify(detail)
    )
  }


  return response.json()
}


export {
  API_URL,
}